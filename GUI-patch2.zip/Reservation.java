/**
 * The Reservation class represents a booking made by a guest for a room.
 * It contains details such as the guest's name, check-in and check-out dates,
 * the room information, and the total price for the stay.
 */
public class Reservation {
    private String guestName;
    private int checkIn;
    private int checkOut;
    private Room roomInfo;
    private double totalPrice;
    private int discount = 0;

    /**
     * Constructor to create a new Reservation with the given details.
     * Calculates the total price based on the number of nights and the room's base price.
     *
     * @param guestName the name of the guest making the reservation
     * @param checkIn the check-in date (1-based index)
     * @param checkOut the check-out date (1-based index)
     * @param roomInfo the Room object containing details about the booked room
     */
    public Reservation(String guestName, int checkIn, int checkOut, Room roomInfo) {
        this.guestName = guestName;
        this.checkIn = checkIn - 1;
        this.checkOut = checkOut - 1;
        this.roomInfo = roomInfo;

        // Calculate the number of nights the guest will stay
        //int nights = checkOut - checkIn;
        // Calculate the total price for the stay
        //this.totalPrice = nights * roomInfo.getBasePrice();

        this.totalPrice = calcTotalPrice(0);
    }

    /**
     * Gets the name of the guest who made the reservation.
     *
     * @return the guest's name
     */
    public String getGuestName() {
        return guestName;
    }

    /**
     * Gets the Room object containing information about the booked room.
     *
     * @return the Room object
     */
    public Room getRoomInfo() {
        return roomInfo;
    }

    /**
     * Gets the check-in date of the reservation.
     *
     * @return the check-in date
     */
    public int getCheckIn() {
        return checkIn + 1;
    }

    /**
     * Gets the check-out date of the reservation.
     *
     * @return the check-out date
     */
    public int getCheckOut() {
        return checkOut + 1;
    }

    /**
     * Gets the total price of the reservation.
     *
     * @return the total price of the reservation
     */
    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double newPrice){
        this.totalPrice = newPrice;
    }

    public int getDiscount(){
        return discount;
    }

    public void setDiscount(int n){
        this.discount = n;
    }

    public double calcTotalPrice(int n){
        int i;
        double sum = 0;

        for (i = checkIn + n; i < checkOut; i++){
            sum = sum + roomInfo.getDPMList().get(i).getNewPrice();
        }

        return sum;
    }

    /**
     * Returns a detailed breakdown of the price for the reservation as a string.
     * @return a formatted string with the price breakdown
     */
    public String getPriceBreakdown() {
        StringBuilder sb = new StringBuilder();

        // Calculate the number of nights the guest will stay
        int nights = checkOut - checkIn;

        // Append the breakdown of the cost per night and the total cost
        sb.append("  Cost Breakdown per Night:\n");
        sb.append("  -----------------------------\n");
        
        // Append the base price per night
        sb.append(String.format("  Base Price per Night: $%.1f\n", roomInfo.getBasePrice()));

        // Append the prices for each day
        if (discount == 2)
            checkIn += 1; // Skips a day.
        for (int i = checkIn; i < checkOut; i++) {
            sb.append(String.format("    Day %d Price: $%.1f\n", i, roomInfo.getDPMList().get(i).getNewPrice()));
        }
        checkIn -= 1; // Returns the number of days back to normal.

        // Append the number of nights
        sb.append(String.format("  Number of Nights:     %d\n", nights));
        sb.append("  -----------------------------\n");
        sb.append(discountScenario()).append("\n");
        sb.append("  -----------------------------\n");

        // Append the total cost
        sb.append(String.format("  Total Cost:           $%.1f%n", totalPrice));

        return sb.toString();
    }

       /**
     * Returns the discount scenario as a string.
     * @return a formatted string with the discount information
     */
    public String discountScenario() {
        StringBuilder scenario = new StringBuilder();

        switch (discount) {
            case 1: 
                scenario.append("        10% Off Total");
                break;
            case 2:
                scenario.append("        Day 1 Free");
                break;
            case 3:
                scenario.append("        7% Off Total");
                break;
            case 0:
                scenario.append("        No Discount Code Used.");
                break;
        }
        return "  Discount Applied:" + scenario.toString();
    }
}
