import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HRSController {
    private HRS model;
    private HRSView view;

    public HRSController(HRS model, HRSView view) {
        this.model = model;
        this.view = view;

        this.view.addCreateHotelListener(new CreateHotelListener());
        this.view.addViewHotelListener(new ViewHotelListener());
        this.view.addManageHotelListener(new ManageHotelListener());
        this.view.addBookReservationListener(new BookReservationListener());
        this.view.addExitListener(new ExitListener());

        updateHotelList();
    }

    private void updateHotelList() {
        view.updateHotelList(model.getHotelList());
    }

    class CreateHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String hotelName = JOptionPane.showInputDialog(view, "Enter the name of the new hotel:");
            
            if (hotelName != null && !hotelName.trim().isEmpty()) {
                // Convert the input to lower case for case-insensitive comparison
                String finalHotelName = hotelName.trim().toLowerCase();
                boolean nameExists = false;

                // Check if a hotel with the same name already exists
                for (Hotel hotel : model.getHotelList()) {
                    if (hotel.getName().toLowerCase().equals(finalHotelName)) {
                        nameExists = true;
                        break;
                    }
                }

                if (nameExists) {
                    // Notify the user that the hotel name already exists
                    JOptionPane.showMessageDialog(view, "A hotel with the name '" + hotelName + "' already exists. Please choose a different name.");
                } else {
                    // Add the new hotel
                    model.addHotel(hotelName);
                    updateHotelList();
                    JOptionPane.showMessageDialog(view, "Hotel '" + hotelName + "' added successfully.");
                }
            }
        }
    }


    class ViewHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) {
                Hotel hotel = model.getHotelList().get(selectedIndex);

                String[] options = {"Hotel Overview", "View Available Rooms on a Date Range", "Room Information", "Reservation Information"};
                String choice = (String) JOptionPane.showInputDialog(view, "Select the information you want to view:",
                        "View Hotel Info", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

                if (choice == null) {
                    return; // User cancelled the dialog
                }

                String result = "";
                try {
                    switch (choice) {
                        case "Hotel Overview":
                            result = hotel.getHighInfo();
                            break;

                        case "View Available Rooms on a Date Range":
                            String checkInInput = JOptionPane.showInputDialog(view, "Enter check-in date (1-30):");
                            if (checkInInput == null) return; // User cancelled
                            
                            try {
                                int checkIn = Integer.parseInt(checkInInput);
                                if (checkIn < 1 || checkIn > 30) {
                                    JOptionPane.showMessageDialog(view, "Invalid check-in date. Please enter a date between 1 and 30.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return; // Exit the case
                                }
                                
                                String checkOutInput = JOptionPane.showInputDialog(view, "Enter check-out date (2-31):");
                                if (checkOutInput == null) return; // User cancelled
                                
                                int checkOut = Integer.parseInt(checkOutInput);
                                if (checkOut < 2 || checkOut > 31 || checkOut <= checkIn) {
                                    JOptionPane.showMessageDialog(view, "Invalid check-out date. Please enter a date between 2 and 31, and ensure it's after the check-in date.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return; // Exit the case
                                }

                                result = hotel.getLowInfo1(checkIn, checkOut);
                                // Display result if needed
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(view, "Invalid input. Please enter numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                            break;

                        case "Room Information":
                            ArrayList<Room> rooms = hotel.getRooms();
                            StringBuilder roomList = new StringBuilder("============= List of Rooms ============= \n");
                            for (int i = 0; i < rooms.size(); i++) {
                                roomList.append("[").append(i + 1).append("] ").append(rooms.get(i).getName()).append("\n");
                            }

                            // Create JTextArea for room list
                            JTextArea roomTextArea = new JTextArea(roomList.toString());
                            roomTextArea.setEditable(false);
                            roomTextArea.setLineWrap(true);
                            roomTextArea.setWrapStyleWord(true);
                            JScrollPane roomScrollPane = new JScrollPane(roomTextArea);
                            roomScrollPane.setPreferredSize(new Dimension(400, 300)); // Adjust dimensions as needed

                            // Create JTextField for room number input
                            JTextField roomNumberField = new JTextField(10);

                            // Create JPanel to hold both JTextArea and JTextField
                            JPanel panel = new JPanel();
                            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
                            panel.add(roomScrollPane);
                            panel.add(Box.createVerticalStrut(10)); // Add some space between components
                            panel.add(new JLabel("Enter room number:"));
                            panel.add(roomNumberField);

                            // Show dialog with room list and input field
                            int resultOption = JOptionPane.showConfirmDialog(view, panel, "Room Information", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOption == JOptionPane.OK_OPTION) {
                                String roomIndexInput = roomNumberField.getText().trim();
                                if (roomIndexInput.isEmpty()) return; // User cancelled or input is empty

                                try {
                                    int roomIndex = Integer.parseInt(roomIndexInput) - 1;
                                    if (roomIndex < 0 || roomIndex >= rooms.size()) {
                                        JOptionPane.showMessageDialog(view, "Invalid room number. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                    } else {
                                        // Get the room details
                                        String roomDetails = hotel.getLowInfo2(roomIndex);

                                        // Create a JTextArea for room details
                                        JTextArea detailsTextArea = new JTextArea(roomDetails);
                                        detailsTextArea.setEditable(false);
                                        detailsTextArea.setLineWrap(true);
                                        detailsTextArea.setWrapStyleWord(true);
                                        JScrollPane detailsScrollPane = new JScrollPane(detailsTextArea);
                                        detailsScrollPane.setPreferredSize(new Dimension(400, 300)); // Adjust dimensions as needed

                                        // Show the details in a new dialog
                                        JOptionPane.showMessageDialog(view, detailsScrollPane, "Room Details", JOptionPane.INFORMATION_MESSAGE);
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                            break;

                        case "Reservation Information":
                            ArrayList<Reservation> reservations = hotel.getReservations();
                            if (reservations.isEmpty()) {
                                JOptionPane.showMessageDialog(view, "There are no reservations available.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            StringBuilder guestList = new StringBuilder("List of Guests:\n");
                            for (int i = 0; i < reservations.size(); i++) {
                                guestList.append("[").append(i + 1).append("] ").append(reservations.get(i).getGuestName()).append("\n");
                            }
                            String guestIndexInput = JOptionPane.showInputDialog(view, guestList.toString() + "\nEnter guest number:");
                            if (guestIndexInput == null) return; // User cancelled
                            int guestIndex = Integer.parseInt(guestIndexInput) - 1;
                            result = hotel.getLowInfo3(guestIndex);
                            break;
                    }
                } catch (NumberFormatException ex) {
                    result = "Invalid input. Please enter a valid number.";
                } catch (IndexOutOfBoundsException ex) {
                    result = "Invalid index. Please select a valid option from the list.";
                } catch (Exception ex) {
                    result = "An error occurred: " + ex.getMessage();
                }

                JOptionPane.showMessageDialog(view, result, "Hotel Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to view.");
            }
        }
    }


    class ManageHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) { 
                Hotel hotel = model.getHotelList().get(selectedIndex);
                // Implement management options
                String[] options = {"Change Name", "Add Room", "Remove Room", "Update Base Price", "Remove Reservation", "Remove Hotel"};
                int choice = JOptionPane.showOptionDialog(view, "Manage Hotel: " + hotel.getName(), "Manage Hotel",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                switch (choice) {
                    case 0:
                        String newName = JOptionPane.showInputDialog(view, "Enter new name:");
                        if (newName != null && !newName.trim().isEmpty()) {
                            hotel.setHotelName(newName);
                            updateHotelList();
                            JOptionPane.showMessageDialog(view, "Hotel name updated to '" + newName + "'.");
                        }
                        break;
                    
                    case 1:
                        // Combined input for number of rooms and type
                        JPanel panel = new JPanel();
                        panel.add(new JLabel("Number of rooms to add:"));
                        JTextField numRoomsField = new JTextField(5);
                        panel.add(numRoomsField);

                        panel.add(new JLabel("Room type:"));
                        String[] roomTypes = {"Standard", "Deluxe", "Executive"};
                        JComboBox<String> roomTypeCombo = new JComboBox<>(roomTypes);
                        panel.add(roomTypeCombo);

                        int result = JOptionPane.showConfirmDialog(view, panel, "Add Rooms",
                                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                        if (result == JOptionPane.OK_OPTION) {
                            String numRoomsText = numRoomsField.getText();
                            int numRooms;
                            try {
                                numRooms = Integer.parseInt(numRoomsText);
                                if (numRooms <= 0 || numRooms > 50) {
                                    JOptionPane.showMessageDialog(view, "Please enter a number between 1 and 50.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(view, "Invalid number format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            int roomType = roomTypeCombo.getSelectedIndex() + 1;
                            if (hotel.getRooms().size() + numRooms > 50) {
                                JOptionPane.showMessageDialog(view, "Adding these rooms would exceed the maximum limit of 50 rooms.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            hotel.addRoom(numRooms, roomType);
                            JOptionPane.showMessageDialog(view, numRooms + " " + roomTypes[roomType - 1] + " rooms added successfully.");
                        }
                        break;

                    case 2:
                        // Remove room logic
                        break;
                    case 3:
                        // Update base price logic
                        break;
                    case 4:
                        // Remove reservation logic
                        break;
                    case 5:
                        model.removeHotel(selectedIndex);
                        updateHotelList();
                        JOptionPane.showMessageDialog(view, "Hotel removed successfully.");
                        break;
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to manage.");
            }
        }
    }

    class BookReservationListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Implement booking logic
        }
    }

    class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int confirm = JOptionPane.showConfirmDialog(view, "Are you sure you want to exit?");
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
    }

}
