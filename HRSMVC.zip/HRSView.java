import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The {@code HRSView} class is a Swing-based graphical user interface (GUI)
 * for the Hotel Reservation System (HRS). It provides various components
 * for user interaction, including buttons for creating, viewing, managing hotels,
 * booking reservations, and exiting the application. It also includes a list
 * to display hotels and custom panels with background images and gradient buttons.
 */
public class HRSView extends JFrame {

    // Buttons for different functionalities within the HRS
    private JButton createHotelButton;
    private JButton viewHotelButton;
    private JButton manageHotelButton;
    private JButton bookReservationButton;
    private JButton exitButton;

    // List and model to display hotels
    private JList<String> hotelList;
    private DefaultListModel<String> listModel;

    /**
     * Constructs the {@code HRSView} object, initializes the GUI components,
     * and sets up the layout and appearance of the main window.
     */
    public HRSView() {
        // Set up the main frame properties
        setTitle("Hotel Reservation System");
        setSize(1200, 500); // Adjusted size to accommodate new space
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize buttons with gradient background
        createHotelButton = new GradientButton("Create Hotel");
        viewHotelButton = new GradientButton("View Hotel");
        manageHotelButton = new GradientButton("Manage Hotel");
        bookReservationButton = new GradientButton("Book a Reservation");
        exitButton = new GradientButton("Exit");

        // Initialize list model and JList with custom style
        listModel = new DefaultListModel<>();
        hotelList = new JList<>(listModel);
        hotelList.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        hotelList.setFont(new Font("Futura", Font.PLAIN, 14));

        // Create a panel for buttons and set layout
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(new Color(0xF0F0F0));
        buttonPanel.add(createHotelButton);
        buttonPanel.add(viewHotelButton);
        buttonPanel.add(manageHotelButton);
        buttonPanel.add(bookReservationButton);
        buttonPanel.add(exitButton);

        // Create a panel for the main content area
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(new JScrollPane(hotelList), BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.EAST);

        // Create a panel for the title with a background image
        JPanel titlePanel = new TitleBackgroundPanel("/upperPanel.jpg");
        titlePanel.setLayout(new GridBagLayout()); // Use GridBagLayout for centering
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        JLabel titleLabel = new JLabel("Hotel Reservation System");
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0xFFFFFF));
        titlePanel.add(titleLabel, gbc);

        // Create a panel for the background picture on the left
        JPanel leftPanel = new BackgroundPanel("/leftPanel.png");
        leftPanel.setPreferredSize(new Dimension(400, 250));
        leftPanel.setLayout(new BorderLayout());

        // Combine the title panel and content panel into a center panel
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(titlePanel, BorderLayout.NORTH);
        centerPanel.add(contentPanel, BorderLayout.CENTER);

        // Set the overall layout and add all panels to the main frame
        setLayout(new BorderLayout());
        add(leftPanel, BorderLayout.WEST);
        add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * A custom button class with a gradient background.
     */
    private class GradientButton extends JButton {
        public GradientButton(String text) {
            super(text);
            setFont(new Font("Futura", Font.BOLD, 14)); // Use Futura or an alternative font
            setForeground(new Color(0x345E7D)); 
            setFocusPainted(false);
            setOpaque(false);
            setBorderPainted(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            // Gradient from a light sandy color to a darker sandy color
            GradientPaint gradient = new GradientPaint(
                0, 0, new Color(0xF0E5DE), // Light sandy color
                0, getHeight(), new Color(0xD5BFA5)  // Slightly darker sandy color
            );
            g2d.setPaint(gradient);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.DARK_GRAY);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
        }
    }

    /**
     * A custom panel class with a background image.
     */
    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String filePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(filePath)).getImage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    /**
     * A custom panel class for the title with a background image.
     */
    private class TitleBackgroundPanel extends JPanel {
        private Image backgroundImage;

        public TitleBackgroundPanel(String filePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(filePath)).getImage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    /**
     * Adds an {@code ActionListener} to the "Create Hotel" button.
     *
     * @param listenForCreateHotelButton the {@code ActionListener} to add
     */
    public void addCreateHotelListener(ActionListener listenForCreateHotelButton) {
        createHotelButton.addActionListener(listenForCreateHotelButton);
    }

    /**
     * Adds an {@code ActionListener} to the "View Hotel" button.
     *
     * @param listenForViewHotelButton the {@code ActionListener} to add
     */
    public void addViewHotelListener(ActionListener listenForViewHotelButton) {
        viewHotelButton.addActionListener(listenForViewHotelButton);
    }

    /**
     * Adds an {@code ActionListener} to the "Manage Hotel" button.
     *
     * @param listenForManageHotelButton the {@code ActionListener} to add
     */
    public void addManageHotelListener(ActionListener listenForManageHotelButton) {
        manageHotelButton.addActionListener(listenForManageHotelButton);
    }

    /**
     * Adds an {@code ActionListener} to the "Book a Reservation" button.
     *
     * @param listenForBookReservationButton the {@code ActionListener} to add
     */
    public void addBookReservationListener(ActionListener listenForBookReservationButton) {
        bookReservationButton.addActionListener(listenForBookReservationButton);
    }

    /**
     * Adds an {@code ActionListener} to the "Exit" button.
     *
     * @param listenForExitButton the {@code ActionListener} to add
     */
    public void addExitListener(ActionListener listenForExitButton) {
        exitButton.addActionListener(listenForExitButton);
    }

    /**
     * Updates the list of hotels displayed in the hotel list component.
     *
     * @param hotels the list of {@code Hotel} objects to display
     */
    public void updateHotelList(ArrayList<Hotel> hotels) {
        listModel.clear();
        for (Hotel hotel : hotels) {
            listModel.addElement(hotel.getName());
        }
    }

    /**
     * Gets the index of the currently selected hotel in the list.
     *
     * @return the index of the selected hotel, or -1 if no hotel is selected
     */
    public int getSelectedHotelIndex() {
        return hotelList.getSelectedIndex();
    }
}
