import java.util.*;

/**
 * Main class for the Hotel Reservation System (HRS) application.
 * It initializes and displays the MVC components of the application.
 */
public class HRSMVC {
    /**
     * Main method to start the application.
     * 
     * This method creates instances of the model, view, and controller,
     * sets up their relationships, and displays the view.
     * 
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        HRS model = new HRS();
        HRSView view = new HRSView();
        HRSController controller = new HRSController(model, view);

        view.setVisible(true);
    }
}
