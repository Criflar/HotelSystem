/**
 * The Reservation class represents a booking made by a guest for a room.
 * It contains details such as the guest's name, check-in and check-out dates,
 * the room information, and the total price for the stay.
 */
public class Reservation {
    private String guestName;
    private int checkIn;
    private int checkOut;
    private Room roomInfo;
    private double totalPrice;
    private int discount = 0;

    // Constructor
    public Reservation(String guestName, int checkIn, int checkOut, Room roomInfo) {
        this.guestName = guestName;
        this.checkIn = checkIn - 1;
        this.checkOut = checkOut - 1;
        this.roomInfo = roomInfo;

        // Calculate the initial total price
        this.totalPrice = calcTotalPrice(0);
    }

    // Getters and setters
    public String getGuestName() { return guestName; }
    public Room getRoomInfo() { return roomInfo; }
    public int getCheckIn() { return checkIn + 1; }
    public int getCheckOut() { return checkOut + 1; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double newPrice) { this.totalPrice = newPrice; }
    public int getDiscount() { return discount; }
    public void setDiscount(int n) { this.discount = n; }

    // Calculate total price
    public double calcTotalPrice(int n) {
        double sum = 0;
        for (int i = checkIn + n; i < checkOut; i++) {
            sum += roomInfo.getDPMList().get(i).getNewPrice();
        }
        return sum;
    }

    // Get price breakdown
    public String getPriceBreakdown() {
        StringBuilder sb = new StringBuilder();
        int nights = checkOut - checkIn;

        sb.append("  Cost Breakdown per Night:\n")
          .append("  -----------------------------\n")
          .append(String.format("  Base Price per Night: $%.1f\n", roomInfo.getBasePrice()));

        if (discount == 2) checkIn += 1; // Adjust for discount
        for (int i = checkIn + 1; i < checkOut + 1; i++) {
            sb.append(String.format("    Day %d Price: $%.1f\n", i, roomInfo.getDPMList().get(i).getNewPrice()));
        }
        if (discount == 2) checkIn -= 1; // Revert adjustment

        sb.append(String.format("  Number of Nights:     %d\n", nights))
          .append("  -----------------------------\n")
          .append(discountScenario()).append("\n")
          .append("  -----------------------------\n")
          .append(String.format("  Total Cost:           $%.1f%n", totalPrice));

        return sb.toString();
    }

    // Get discount scenario
    public String discountScenario() {
        StringBuilder scenario = new StringBuilder();
        switch (discount) {
            case 1: scenario.append("        10% Off Total"); break;
            case 2: scenario.append("        Day 1 Free"); break;
            case 3: scenario.append("        7% Off Total"); break;
            case 0: scenario.append("        No Discount Code Used."); break;
        }
        return "  Discount Applied:" + scenario.toString();
    }
}
