public class discount2 extends discount{
    
    double calculateDiscount(Reservation r){

        return r.calcTotalPrice(1);

    }

}
