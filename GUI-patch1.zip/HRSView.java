import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class HRSView extends JFrame {
    private JButton createHotelButton;
    private JButton viewHotelButton;
    private JButton manageHotelButton;
    private JButton bookReservationButton;
    private JButton exitButton;
    private JList<String> hotelList;
    private DefaultListModel<String> listModel;

    public HRSView() {
        setTitle("Hotel Reservation System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createHotelButton = new JButton("Create Hotel");
        viewHotelButton = new JButton("View Hotel");
        manageHotelButton = new JButton("Manage Hotel");
        bookReservationButton = new JButton("Book a Reservation");
        exitButton = new JButton("Exit");

        listModel = new DefaultListModel<>();
        hotelList = new JList<>(listModel);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1));
        buttonPanel.add(createHotelButton);
        buttonPanel.add(viewHotelButton);
        buttonPanel.add(manageHotelButton);
        buttonPanel.add(bookReservationButton);
        buttonPanel.add(exitButton);

        panel.add(new JScrollPane(hotelList), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.EAST);

        add(panel);
    }

    public void addCreateHotelListener(ActionListener listenForCreateHotelButton) {
        createHotelButton.addActionListener(listenForCreateHotelButton);
    }

    public void addViewHotelListener(ActionListener listenForViewHotelButton) {
        viewHotelButton.addActionListener(listenForViewHotelButton);
    }

    public void addManageHotelListener(ActionListener listenForManageHotelButton) {
        manageHotelButton.addActionListener(listenForManageHotelButton);
    }

    public void addBookReservationListener(ActionListener listenForBookReservationButton) {
        bookReservationButton.addActionListener(listenForBookReservationButton);
    }

    public void addExitListener(ActionListener listenForExitButton) {
        exitButton.addActionListener(listenForExitButton);
    }

    public void updateHotelList(ArrayList<Hotel> hotels) {
        listModel.clear();
        for (Hotel hotel : hotels) {
            listModel.addElement(hotel.getName());
        }
    }

    public int getSelectedHotelIndex() {
        return hotelList.getSelectedIndex();
    }
}
