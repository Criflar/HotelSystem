import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuView extends JFrame {
    private HotelReservationSystem HRS;

    public MainMenuView(HotelReservationSystem HRS) {
        this.HRS = HRS;
        setTitle("Hotel Reservation System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("Hotel Reservation System");
        titleLabel.setBounds(100, 20, 200, 30);
        panel.add(titleLabel);

        JButton manageHotelButton = new JButton("Manage Hotel");
        manageHotelButton.setBounds(100, 70, 200, 30);
        panel.add(manageHotelButton);
        manageHotelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ManageHotelView(HRS).setVisible(true);
                dispose();
            }
        });

        JButton bookReservationButton = new JButton("Book Reservation");
        bookReservationButton.setBounds(100, 110, 200, 30);
        panel.add(bookReservationButton);
        bookReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement Book Reservation view transition here
            }
        });

        JButton viewAllReservationsButton = new JButton("View All Reservations");
        viewAllReservationsButton.setBounds(100, 150, 200, 30);
        panel.add(viewAllReservationsButton);
        viewAllReservationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement View All Reservations view transition here
            }
        });

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(100, 190, 200, 30);
        panel.add(exitButton);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainMenuView mainMenuView = new MainMenuView(new HotelReservationSystem());
            mainMenuView.setVisible(true);
        });
    }
}
