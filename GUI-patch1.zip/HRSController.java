import java.util.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HRSController {
    private HRS model;
    private HRSView view;

    public HRSController(HRS model, HRSView view) {
        this.model = model;
        this.view = view;

        this.view.addCreateHotelListener(new CreateHotelListener());
        this.view.addViewHotelListener(new ViewHotelListener());
        this.view.addManageHotelListener(new ManageHotelListener());
        this.view.addBookReservationListener(new BookReservationListener());
        this.view.addExitListener(new ExitListener());

        updateHotelList();
    }

    private void updateHotelList() {
        view.updateHotelList(model.getHotelList());
    }

    class CreateHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String hotelName = JOptionPane.showInputDialog(view, "Enter the name of the new hotel:");
            
            if (hotelName != null && !hotelName.trim().isEmpty()) {
                // Convert the input to lower case for case-insensitive comparison
                String finalHotelName = hotelName.trim().toLowerCase();
                boolean nameExists = false;

                // Check if a hotel with the same name already exists
                for (Hotel hotel : model.getHotelList()) {
                    if (hotel.getName().toLowerCase().equals(finalHotelName)) {
                        nameExists = true;
                        break;
                    }
                }

                if (nameExists) {
                    // Notify the user that the hotel name already exists
                    JOptionPane.showMessageDialog(view, "A hotel with the name '" + hotelName + "' already exists. Please choose a different name.");
                } else {
                    // Add the new hotel
                    model.addHotel(hotelName);
                    updateHotelList();
                    JOptionPane.showMessageDialog(view, "Hotel '" + hotelName + "' added successfully.");
                }
            }
        }
    }

    class ViewHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) {
                Hotel hotel = model.getHotelList().get(selectedIndex);
                JOptionPane.showMessageDialog(view, "Hotel Name: " + hotel.getName());
                // Display more hotel details as needed
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to view.");
            }
        }
    }

    class ManageHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) { 
                Hotel hotel = model.getHotelList().get(selectedIndex);
                // Implement management options
                String[] options = {"Change Name", "Add Room", "Remove Room", "Update Base Price", "Remove Reservation", "Remove Hotel"};
                int choice = JOptionPane.showOptionDialog(view, "Manage Hotel: " + hotel.getName(), "Manage Hotel",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                switch (choice) {
                    case 0:
                        String newName = JOptionPane.showInputDialog(view, "Enter new name:");
                        if (newName != null && !newName.trim().isEmpty()) {
                            hotel.setHotelName(newName);
                            updateHotelList();
                            JOptionPane.showMessageDialog(view, "Hotel name updated to '" + newName + "'.");
                        }
                        break;
                    case 1:
                        // Add room logic
                        break;
                    case 2:
                        // Remove room logic
                        break;
                    case 3:
                        // Update base price logic
                        break;
                    case 4:
                        // Remove reservation logic
                        break;
                    case 5:
                        model.removeHotel(selectedIndex);
                        updateHotelList();
                        JOptionPane.showMessageDialog(view, "Hotel removed successfully.");
                        break;
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to manage.");
            }
        }
    }

    class BookReservationListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Implement booking logic
        }
    }

    class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int confirm = JOptionPane.showConfirmDialog(view, "Are you sure you want to exit?");
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
    }
}
