public interface DPMInterface {
    
    public void setModifier(double n);

    public double getNewPrice();

    public void setBasePrice(double basePrice);

}
