public abstract class discount {
    
    abstract double calculateDiscount(Reservation r);

}
