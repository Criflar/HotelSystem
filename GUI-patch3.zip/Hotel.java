import java.util.ArrayList;
import java.util.Scanner;

/**
 * The Hotel class represents a hotel with a name, rooms, and reservations.
 * It provides functionality to manage rooms, reservations, and to view information about the hotel.
 */
public class Hotel {
    private String name;
    private ArrayList<Room> rooms = new ArrayList<>();
    private ArrayList<Reservation> reservations = new ArrayList<>();
    private double earnings;
    private int totalAvailable;
    private int totalBooked;
    private Scanner input = new Scanner(System.in);
    private double roomPrice = 1299.00;

    /**
     * Constructor to create a Hotel with a specified name.
     * Initializes with one room ("A0") and updates earnings.
     *
     * @param name the name of the hotel
     */
    public Hotel(String name) {
        this.name = name;
        rooms.add(new Room("A0", roomPrice)); // Initial room setup, first room is Standard.
        updateEarnings();
    }

    /**
     * Sets the name of the hotel.
     *
     * @param name the new name of the hotel
     */
    public void setHotelName(String name) {
        this.name = name;
        System.out.println("Hotel name updated to: " + name + "\n");
    }

    /**
     * Gets the name of the hotel.
     *
     * @return the name of the hotel
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the list of rooms in the hotel.
     *
     * @return an ArrayList of Room objects
     */
    public ArrayList<Room> getRooms() {
        return rooms;
    }

    /**
     * Gets the list of reservations in the hotel.
     *
     * @return an ArrayList of Reservation objects
     */
    public ArrayList<Reservation> getReservations() {
        return reservations;
    }

    /**
     * Finds the index of the next available room for the given dates.
     *
     * @param checkIn  the check-in date
     * @param checkOut the check-out date
     * @return the index of the next available room, or -1 if none are available
     */
    public int getNextRoom(int checkIn, int checkOut) {
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms.get(i).checkAvailability(checkIn, checkOut)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Gets the Room object at the specified index.
     *
     * @param n the index of the room
     * @return the Room object at the specified index
     */
    public Room getRoom(int n) {
        return rooms.get(n);
    }

    /**
    * Returns a string containing high-level information about the hotel, such as the name, number of rooms, and earnings forecast.
     @return the string of the info.
    */
    public String getHighInfo() {
        // Construct the formatted string
        StringBuilder sb = new StringBuilder();
        sb.append("\n============= Hotel Overview =============\n");
        sb.append("Name: ").append(name).append("\n");
        sb.append("Total number of rooms: ").append(rooms.size()).append("\n");
        sb.append("Earning forecast for the month: $").append(String.format("%.2f", earnings)).append("\n");

        return sb.toString();
    }


    /**
     * Returns a string containing low-level information about the availability and booking status of rooms for specified dates.
     * @param checkIn the check-in date (1-30)
     * @param checkOut the check-out date (2-31, after check-in date)
     * @return a formatted string with availability and booking information
     */
    public String getLowInfo1(int checkIn, int checkOut) {
        // Validate input parameters
        if (checkIn <= 0 || checkIn >= 31 || checkOut >= 32 || checkOut <= 1 || checkOut <= checkIn) {
            throw new IllegalArgumentException("Invalid check-in or check-out date.");
        }

        // Get the total available and booked rooms
        getTotalAvailable(checkIn, checkOut);
        getTotalBooked(checkIn, checkOut);

        // Construct the formatted string
        StringBuilder sb = new StringBuilder();
        sb.append("\n============= Available Rooms at your Selected Date =============\n");
        sb.append("For Days ").append(checkIn).append(" to ").append(checkOut).append(", here are the total available and booked rooms:\n");
        sb.append("AVAILABLE: ").append(totalAvailable).append("\n");
        sb.append("Booked: ").append(totalBooked).append("\n");

        return sb.toString();
    }


    /**
     * Returns a string containing detailed information about a selected room.
     * @param roomIndex the index of the room (1-based)
     * @return a formatted string with detailed room information
     */
    public String getLowInfo2(int roomIndex) {
        
        // Validate room index
        if (roomIndex < 0 || roomIndex >= rooms.size()) {
            throw new IllegalArgumentException("Invalid room index.");
        }

        // Retrieve the selected room
        Room selectedRoom = rooms.get(roomIndex);

        // Construct the formatted string
        StringBuilder sb = new StringBuilder();
        sb.append("\nRoom Name: ").append(selectedRoom.getName());
        sb.append("\nPrice per Night: ").append(selectedRoom.getBasePrice());
        sb.append("\nAvailability of the room for the month: \n");
        // Assuming `displayBooked` returns a string or modify to append results as needed
        sb.append(selectedRoom.getBookedStatus("YES")).append("\n");

        return sb.toString();
    }

    /**
     * Returns a string containing detailed information about a selected reservation.
     * @param guestIndex the index of the guest's reservation (0-based)
     * @return a formatted string with detailed reservation information
     */
    public String getLowInfo3(int guestIndex) {

        // Validate guest index
        if (reservations.isEmpty()) {
            return "\nThere are currently no reservations made to this hotel.\n";
        }

        if (guestIndex < 0 || guestIndex >= reservations.size()) {
            throw new IllegalArgumentException("Invalid guest index.");
        }

        // Retrieve the selected reservation
        Reservation selectedReservation = reservations.get(guestIndex);

        // Construct the formatted string
        StringBuilder sb = new StringBuilder();
        sb.append("\nGuest Name: ").append(selectedReservation.getGuestName()).append("\n");
        sb.append("Room Info: \n");
        sb.append("  Room Name: ").append(selectedReservation.getRoomInfo().getName()).append("\n");
        sb.append("  Room Base Price: ").append(selectedReservation.getRoomInfo().getBasePrice()).append("\n");
        sb.append("  Check-in Date: Day ").append(selectedReservation.getCheckIn()).append("\n");
        sb.append("  Check-out Date: Day ").append(selectedReservation.getCheckOut()).append("\n");
        sb.append("  Active Discount: ");
        sb.append(getDiscountDisplay(selectedReservation)).append("\n");
        sb.append("  Total Price for Stay: $").append(String.format("%.2f", selectedReservation.getTotalPrice())).append("\n");
        sb.append(selectedReservation.getPriceBreakdown()).append("\n");

        return sb.toString();
    }


    /**
     * Returns a string describing the discount applied to the reservation.
     * @param r the reservation object
     * @return a formatted string with the discount description
     */
    public String getDiscountDisplay(Reservation r) {
        String discountDescription;

        switch (r.getDiscount()) {
            case 1:
                discountDescription = "\"I_WORK_HERE\"";
                break;

            case 2:
                discountDescription = "\"STAY4_GET1\"";
                break;

            case 3:
                discountDescription = "\"PAYDAY\"";
                break;

            case 0:
            default:
                discountDescription = "N/A";
                break;
        }

        return discountDescription;
    }


    /**
     * Checks the availability of rooms for the given dates and displays the available rooms.
     *
     * @param checkIn  the check-in date (1-based index)
     * @param checkOut the check-out date (1-based index)
     * @return true if there are available rooms, false otherwise
     */
    public boolean getAvailRooms(int checkIn, int checkOut) {
        boolean avail = false;
        System.out.println("The following are the available rooms on your scheduled dates: ");
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms.get(i).checkAvailability(checkIn, checkOut)) {
                System.out.println((i + 1) + ". Room \u001b[36;1m" + rooms.get(i).getName() + "\u001b[0m: \u001b[32;1mAVAILABLE\u001b[0m");
                avail = true;
            }
        }
        return avail;
    }

    /**
     * Checks the availability of all rooms for the given dates and displays their status.
     *
     * @param checkIn  the check-in date (1-based index)
     * @param checkOut the check-out date (1-based index)
     * @return true if there are available rooms, false otherwise
     */
    public boolean getAllRooms(int checkIn, int checkOut) {
        boolean avail = false;
        System.out.println("The following are the rooms and their status on your scheduled dates: ");
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms.get(i).checkAvailability(checkIn, checkOut)) {
                System.out.println((i + 1) + ". Room \u001b[36;1m" + rooms.get(i).getName() + "\u001b[0m: \u001b[32;1mAVAILABLE\u001b[0m");
                avail = true;
            } else {
                System.out.println((i + 1) + ". Room \u001b[36;1m" + rooms.get(i).getName() + "\u001b[0m: \u001b[31;1mBooked\u001b[0m");
            }
        }
        return avail;
    }

    public Room pickAvailableRoom(int checkIn, int checkOut) {
        for (Room room : rooms) {
            if (room.checkAvailability(checkIn, checkOut)) {
                return room;
            }
        }
        return null;
    }
    

    /**
     * Calculates the total number of available rooms for the given dates.
     *
     * @param checkIn  the check-in date
     * @param checkOut the check-out date
     */
    private void getTotalAvailable(int checkIn, int checkOut) {
        totalAvailable = 0;
        for (Room room : rooms) {
            if (room.checkAvailability(checkIn, checkOut)) {
                totalAvailable++;
            }
        }
    }

    /**
     * Calculates the total number of booked rooms for the given dates.
     *
     * @param checkIn  the check-in date
     * @param checkOut the check-out date
     */
    private void getTotalBooked(int checkIn, int checkOut) {
        totalBooked = 0;
        for (Room room : rooms) {
            if (!room.checkAvailability(checkIn, checkOut)) {
                totalBooked++;
            }
        }
    }

    /**
     * Displays the list of all rooms in the hotel.
     */
    public void displayRooms() {
        System.out.println("\nList of rooms in the hotel:");
        for (int i = 0; i < rooms.size(); i++) {
            System.out.println("[" + (i + 1) + "] Room: \u001b[36;1m" + rooms.get(i).getName() + "\u001b[0m");
        }
    }

    /**
     * Adds a specified number of rooms to the hotel.
     *
     * @param n the number of rooms to add
     * @param type the type of room to add
     */
    public void addRoom(int n, int type) { // 1 - Standard, 2 - Deluxe, 3 - Executive
        for (int i = 0; i < n; i++) {
            String lastRoomName = rooms.get(rooms.size() - 1).getName();
            char letterPart = lastRoomName.charAt(0); // Get the letter part of the room name
            int numberPart = Character.getNumericValue(lastRoomName.charAt(1)); // Get the number part of the room name
            //int numberPart = Integer.parseInt(lastRoomName.substring(1)); // Get the number part of the room name

            numberPart++;
            if (numberPart == 10) {
                letterPart++;
                numberPart = 0;
            }

            String newRoomName = String.format("%c%d", letterPart, numberPart);

            switch (type) {
                case 0:
                    System.out.println("Going back to the previous menu...");
                    break;
                    
                case 1: 
                    rooms.add(new Room(newRoomName, roomPrice));
                    break;

                case 2:
                    rooms.add(new DeluxeRoom(newRoomName + " (Deluxe)", roomPrice));
                    break;

                case 3:
                    rooms.add(new ExecutiveRoom(newRoomName + " (Executive)", roomPrice));
                    break;
            }
            
        }
    }

    /**
     * Removes the room at the specified index, if it has no reservations.
     *
     * @param index the index of the room to remove
     */
    public void removeRoom(int index) {
        if (rooms.size() == 1) {
            System.out.println("\nSorry, there should at least be 1 room in Hotel " + name + ".");
            return;
        }
        for (int i = 0; i < rooms.size(); i++) {
            if (rooms.get(i) == rooms.get(index - 1)) {
                boolean canRemove = true;
                for (Reservation reservation : reservations) {
                    if (reservation.getRoomInfo() == rooms.get(index - 1)) {
                        canRemove = false;
                        break;
                    }
                }
                if (canRemove) {
                    System.out.println("\nRoom \u001b[36;1m" + rooms.get(i).getName() + "\u001b[0m removed successfully.");
                    rooms.remove(i);
                } else {
                    System.out.println("\nThe room " + rooms.get(i).getName() + " has reservations and cannot be removed.");
                }
                return;
            }
        }
        System.out.println("Room " + rooms.get(index - 1) + " not found.");
    }

    /**
     * Adds a reservation for the specified guest and dates in the given room.
     *
     * @param guestName the name of the guest
     * @param checkIn   the check-in date
     * @param checkOut  the check-out date
     * @param room      the room to reserve
     */
    public boolean addReservation(String guestName, int checkIn, int checkOut, Room room, int discountApplied) {  
        if (room.checkAvailability(checkIn, checkOut)) {
            Reservation r = new Reservation(guestName, checkIn, checkOut, room);
            reservations.add(r);
            updateRoomAvailability(room, checkIn, checkOut, true);

            applyDiscount(discountApplied, r);

            updateEarnings();

            return true;

        } else {
            System.out.println("Room " + room.getName() + " is not available for the selected dates.");
            return false;
        }
    }

    public void applyDiscount(int discountApplied, Reservation r) {
        double newPrice;

        r.setDiscount(discountApplied);

        if (discountApplied != 0) {
            switch (discountApplied) {
                case 1:
                    discount1 dc1 = new discount1();
                    newPrice = dc1.calculateDiscount(r);
                    r.setTotalPrice(newPrice);
                    break;

                case 2:
                    discount2 dc2 = new discount2();
                    newPrice = dc2.calculateDiscount(r);
                    r.setTotalPrice(newPrice);
                    break;

                case 3:
                    discount3 dc3 = new discount3();
                    newPrice = dc3.calculateDiscount(r);
                    r.setTotalPrice(newPrice);
                    break;
            }
        }
    }

    /**
     * Removes a reservation selected by the user.
     * @param guestIndex the index of the reservation to be removed.
     */
    public void removeReservation(int guestIndex) {
        if (guestIndex >= 0 && guestIndex < reservations.size()) {
            Reservation removedReservation = reservations.remove(guestIndex);
            updateRoomAvailability(removedReservation.getRoomInfo(), removedReservation.getCheckIn(), removedReservation.getCheckOut(), false);
            updateEarnings();
            System.out.println("\nReservation removed successfully.");
        } else {
            System.out.println("Invalid reservation index. Please provide a valid index.");
        }
    }


    /**
     * Updates the base price of all rooms in the hotel.
     *
     * @param price the new base price
     */
    public void updateBasePrice(double price) {
        if (price >= 100.0) { // Ensure the new price is valid
            for (Room room : rooms) {
                room.setBasePrice(price);
            }
            System.out.println("Base price updated successfully.\n");
        } else {
            System.out.println("Invalid value. New price must be greater than or equal to 100.0");
        }
    }


    /**
     * Updates the availability of a room for the specified dates.
     *
     * @param room     the room to update
     * @param checkIn  the check-in date
     * @param checkOut the check-out date
     * @param booked   true if the room is booked, false if it is available
     */
    private void updateRoomAvailability(Room room, int checkIn, int checkOut, boolean booked) {
        for (int i = checkIn - 1; i < checkOut; i++) {
            room.getDaysBooked().set(i, booked);
        }
    }

    public void updateDPM(int dateModified, int modifierValue){

        int i;

        for (i = 0; i < rooms.size(); i++){
            rooms.get(i).getDPMList().get(dateModified).setModifier(modifierValue);
        }

    }

    /**
     * Updates the total earnings of the hotel based on current reservations.
     */
    private void updateEarnings() {
        earnings = 0;
        for (Reservation reservation : reservations) {
            earnings += reservation.getTotalPrice();
        }
    }

    /**
     * Gets the total number of rooms in the hotel.
     *
     * @return the total number of rooms
     */
    public int getRoomAmt() {
        return rooms.size();
    }
}
