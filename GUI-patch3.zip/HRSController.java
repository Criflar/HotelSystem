import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HRSController {
    private HRS model;
    private HRSView view;

    public HRSController(HRS model, HRSView view) {
        this.model = model;
        this.view = view;

        this.view.addCreateHotelListener(new CreateHotelListener());
        this.view.addViewHotelListener(new ViewHotelListener());
        this.view.addManageHotelListener(new ManageHotelListener());
        this.view.addBookReservationListener(new BookReservationListener());
        this.view.addExitListener(new ExitListener());

        updateHotelList();
    }

    private void updateHotelList() {
        view.updateHotelList(model.getHotelList());
    }

    class CreateHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String hotelName = JOptionPane.showInputDialog(view, "Enter the name of the new hotel:");
            
            if (hotelName != null && !hotelName.trim().isEmpty()) {
                // Convert the input to lower case for case-insensitive comparison
                String finalHotelName = hotelName.trim().toLowerCase();
                boolean nameExists = false;

                // Check if a hotel with the same name already exists
                for (Hotel hotel : model.getHotelList()) {
                    if (hotel.getName().toLowerCase().equals(finalHotelName)) {
                        nameExists = true;
                        break;
                    }
                }

                if (nameExists) {
                    // Notify the user that the hotel name already exists
                    JOptionPane.showMessageDialog(view, "A hotel with the name '" + hotelName + "' already exists. Please choose a different name.");
                } else {
                    // Add the new hotel
                    model.addHotel(hotelName);
                    updateHotelList();
                    JOptionPane.showMessageDialog(view, "Hotel '" + hotelName + "' added successfully.");
                }
            }
        }
    }


    class ViewHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) {
                Hotel hotel = model.getHotelList().get(selectedIndex);

                String[] options = {"Hotel Overview", "View Available Rooms on a Date Range", "Room Information", "Reservation Information"};
                String choice = (String) JOptionPane.showInputDialog(view, "Select the information you want to view:",
                        "View Hotel Info", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

                if (choice == null) {
                    return; // User cancelled the dialog
                }

                String result = "";
                try {
                    switch (choice) {
                        case "Hotel Overview":
                            result = hotel.getHighInfo();
                            break;

                        case "View Available Rooms on a Date Range":
                            String checkInInput = JOptionPane.showInputDialog(view, "Enter check-in date (1-30):");
                            if (checkInInput == null) return; // User cancelled
                            
                            try {
                                int checkIn = Integer.parseInt(checkInInput);
                                if (checkIn < 1 || checkIn > 30) {
                                    JOptionPane.showMessageDialog(view, "Invalid check-in date. Please enter a date between 1 and 30.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return; // Exit the case
                                }
                                
                                String checkOutInput = JOptionPane.showInputDialog(view, "Enter check-out date (2-31):");
                                if (checkOutInput == null) return; // User cancelled
                                
                                int checkOut = Integer.parseInt(checkOutInput);
                                if (checkOut < 2 || checkOut > 31 || checkOut <= checkIn) {
                                    JOptionPane.showMessageDialog(view, "Invalid check-out date. Please enter a date between 2 and 31, and ensure it's after the check-in date.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return; // Exit the case
                                }

                                result = hotel.getLowInfo1(checkIn, checkOut);
                                // Display result if needed
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(view, "Invalid input. Please enter numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                            break;

                        case "Room Information":
                            ArrayList<Room> rooms = hotel.getRooms();
                            StringBuilder roomList = new StringBuilder("============= List of Rooms ============= \n");
                            for (int i = 0; i < rooms.size(); i++) {
                                roomList.append("[").append(i + 1).append("] ").append(rooms.get(i).getName()).append("\n");
                            }

                            // Create JTextArea for room list
                            JTextArea roomTextArea = new JTextArea(roomList.toString());
                            roomTextArea.setEditable(false);
                            roomTextArea.setLineWrap(true);
                            roomTextArea.setWrapStyleWord(true);
                            JScrollPane roomScrollPane = new JScrollPane(roomTextArea);
                            roomScrollPane.setPreferredSize(new Dimension(400, 300)); // Adjust dimensions as needed

                            // Create JTextField for room number input
                            JTextField roomNumberField = new JTextField(10);

                            // Create JPanel to hold both JTextArea and JTextField
                            JPanel panel = new JPanel();
                            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
                            panel.add(roomScrollPane);
                            panel.add(Box.createVerticalStrut(10)); // Add some space between components
                            panel.add(new JLabel("Enter room number:"));
                            panel.add(roomNumberField);

                            // Show dialog with room list and input field
                            int resultOption = JOptionPane.showConfirmDialog(view, panel, "Room Information", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOption == JOptionPane.OK_OPTION) {
                                String roomIndexInput = roomNumberField.getText().trim();
                                if (roomIndexInput.isEmpty()) return; // User cancelled or input is empty

                                try {
                                    int roomIndex = Integer.parseInt(roomIndexInput) - 1;
                                    if (roomIndex < 0 || roomIndex >= rooms.size()) {
                                        JOptionPane.showMessageDialog(view, "Invalid room number. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                    } else {
                                        // Get the room details
                                        String roomDetails = hotel.getLowInfo2(roomIndex);

                                        // Create a JTextArea for room details
                                        JTextArea detailsTextArea = new JTextArea(roomDetails);
                                        detailsTextArea.setEditable(false);
                                        detailsTextArea.setLineWrap(true);
                                        detailsTextArea.setWrapStyleWord(true);
                                        JScrollPane detailsScrollPane = new JScrollPane(detailsTextArea);
                                        detailsScrollPane.setPreferredSize(new Dimension(400, 300)); // Adjust dimensions as needed

                                        // Show the details in a new dialog
                                        JOptionPane.showMessageDialog(view, detailsScrollPane, "Room Details", JOptionPane.INFORMATION_MESSAGE);
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                            break;

                        case "Reservation Information":
                            ArrayList<Reservation> reservations = hotel.getReservations();
                            if (reservations.isEmpty()) {
                                JOptionPane.showMessageDialog(view, "There are no reservations available.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            StringBuilder guestList = new StringBuilder("List of Guests:\n");
                            for (int i = 0; i < reservations.size(); i++) {
                                guestList.append("[").append(i + 1).append("] ").append(reservations.get(i).getGuestName()).append("\n");
                            }
                            String guestIndexInput = JOptionPane.showInputDialog(view, guestList.toString() + "\nEnter guest number:");
                            if (guestIndexInput == null) return; // User cancelled
                            int guestIndex = Integer.parseInt(guestIndexInput) - 1;
                            result = hotel.getLowInfo3(guestIndex);
                            break;
                    }
                } catch (NumberFormatException ex) {
                    result = "Invalid input. Please enter a valid number.";
                } catch (IndexOutOfBoundsException ex) {
                    result = "Invalid index. Please select a valid option from the list.";
                } catch (Exception ex) {
                    result = "An error occurred: " + ex.getMessage();
                }

                JOptionPane.showMessageDialog(view, result, "Hotel Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to view.");
            }
        }
    }


    class ManageHotelListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) { 
                Hotel hotel = model.getHotelList().get(selectedIndex);
                // Implement management options
                String[] options = {"Change Name", "Add Room", "Remove Room", "Update Base Price", "Remove Reservation", "Remove Hotel"};
                int choice = JOptionPane.showOptionDialog(view, "Manage Hotel: " + hotel.getName(), "Manage Hotel",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                switch (choice) {
                    case 0:
                        String newName = JOptionPane.showInputDialog(view, "Enter new name:");
                        if (newName != null && !newName.trim().isEmpty()) {
                            hotel.setHotelName(newName);
                            updateHotelList();
                            JOptionPane.showMessageDialog(view, "Hotel name updated to '" + newName + "'.");
                        }
                        break;
                    
                    case 1:
                        // Combined input for number of rooms and type
                        JPanel addRoomPanel = new JPanel();
                        addRoomPanel.add(new JLabel("Number of rooms to add:"));
                        JTextField numRoomsField = new JTextField(5);
                        addRoomPanel.add(numRoomsField);

                        addRoomPanel.add(new JLabel("Room type:"));
                        String[] roomTypes = {"Standard", "Deluxe", "Executive"};
                        JComboBox<String> roomTypeCombo = new JComboBox<>(roomTypes);
                        addRoomPanel.add(roomTypeCombo);

                        int result = JOptionPane.showConfirmDialog(view, addRoomPanel, "Add Rooms",
                                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                        if (result == JOptionPane.OK_OPTION) {
                            String numRoomsText = numRoomsField.getText();
                            int numRooms;
                            try {
                                numRooms = Integer.parseInt(numRoomsText);
                                if (numRooms <= 0 || numRooms > 50) {
                                    JOptionPane.showMessageDialog(view, "Please enter a number between 1 and 50.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(view, "Invalid number format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            int roomType = roomTypeCombo.getSelectedIndex() + 1;
                            if (hotel.getRooms().size() + numRooms > 50) {
                                JOptionPane.showMessageDialog(view, "Adding these rooms would exceed the maximum limit of 50 rooms.", "Error", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            hotel.addRoom(numRooms, roomType);
                            JOptionPane.showMessageDialog(view, numRooms + " " + roomTypes[roomType - 1] + " rooms added successfully.");
                        }
                        break;

                    case 2:
                        if (hotel.getRooms().isEmpty()) {
                            JOptionPane.showMessageDialog(view, "No rooms to remove.");
                        } else {
                            ArrayList<Room> rooms = hotel.getRooms();
                            StringBuilder roomList = new StringBuilder("============= List of Rooms ============= \n");
                            for (int i = 0; i < rooms.size(); i++) {
                                roomList.append("[").append(i + 1).append("] ").append(rooms.get(i).getName()).append("\n");
                            }

                            JTextArea roomTextArea = new JTextArea(roomList.toString());
                            roomTextArea.setEditable(false);
                            roomTextArea.setLineWrap(true);
                            roomTextArea.setWrapStyleWord(true);
                            JScrollPane roomScrollPane = new JScrollPane(roomTextArea);
                            roomScrollPane.setPreferredSize(new Dimension(400, 300));

                            JTextField roomNumberField = new JTextField(10);

                            JPanel removeRoomPanel = new JPanel();
                            removeRoomPanel.setLayout(new BoxLayout(removeRoomPanel, BoxLayout.Y_AXIS));
                            removeRoomPanel.add(roomScrollPane);
                            removeRoomPanel.add(Box.createVerticalStrut(10));
                            removeRoomPanel.add(new JLabel("Enter room numbers (comma separated):"));
                            removeRoomPanel.add(roomNumberField);

                            int resultOption = JOptionPane.showConfirmDialog(view, removeRoomPanel, "Remove Room", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOption == JOptionPane.OK_OPTION) {
                                String roomIndexInput = roomNumberField.getText().trim();
                                if (roomIndexInput.isEmpty()) return;

                                try {
                                    String[] roomIndices = roomIndexInput.split(",");
                                    ArrayList<Integer> indicesToRemove = new ArrayList<>();
                                    for (String index : roomIndices) {
                                        int roomIndex = Integer.parseInt(index.trim());
                                        indicesToRemove.add(roomIndex);
                                    }

                                    // Sort indices in descending order to avoid shifting issues
                                    indicesToRemove.sort(Collections.reverseOrder());

                                    boolean allRemoved = true;
                                    for (int roomIndex : indicesToRemove) {
                                        if (hotel.getRooms().size() == 1) {
                                            JOptionPane.showMessageDialog(view, "Cannot remove room. There must be at least one room in the hotel.");
                                            allRemoved = false;
                                            break;
                                        }

                                        Room roomToRemove = hotel.getRooms().get(roomIndex - 1);
                                        boolean hasReservations = false;

                                        for (Reservation reservation : hotel.getReservations()) {
                                            if (reservation.getRoomInfo() == roomToRemove) {
                                                hasReservations = true;
                                                break;
                                            }
                                        }

                                        if (hasReservations) {
                                            JOptionPane.showMessageDialog(view, "Cannot remove room " + roomToRemove.getName() + ". There are active reservations for this room.");
                                            allRemoved = false;
                                        } else {
                                            hotel.removeRoom(roomIndex);
                                        }
                                    }

                                    if (allRemoved) {
                                        JOptionPane.showMessageDialog(view, "Rooms removed successfully.");
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter valid numbers separated by commas.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        }
                        break;

                    case 3:
                        if (hotel.getReservations().isEmpty()) {
                            String newPriceInput = JOptionPane.showInputDialog(view, "Enter new base price (minimum 100.0):");

                            if (newPriceInput != null) {
                                try {
                                    double newPrice = Double.parseDouble(newPriceInput);

                                    if (newPrice >= 100.0) {
                                        hotel.updateBasePrice(newPrice);
                                        JOptionPane.showMessageDialog(view, "Base price updated successfully to " + newPrice + ".");
                                    } else {
                                        JOptionPane.showMessageDialog(view, "Invalid value. New price must be greater than or equal to 100.0.", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(view, "Cannot update base price. There are active reservations in the hotel.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        break;

                    case 4:
                        if (hotel.getReservations().isEmpty()) {
                            JOptionPane.showMessageDialog(view, "No reservations to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            ArrayList<Reservation> reservations = hotel.getReservations();
                            StringBuilder reservationList = new StringBuilder("============= List of Reservations ============= \n");
                            for (int i = 0; i < reservations.size(); i++) {
                                reservationList.append("[").append(i + 1).append("] Guest: ").append(reservations.get(i).getGuestName()).append("\n");
                            }

                            JTextArea reservationTextArea = new JTextArea(reservationList.toString());
                            reservationTextArea.setEditable(false);
                            reservationTextArea.setLineWrap(true);
                            reservationTextArea.setWrapStyleWord(true);
                            JScrollPane reservationScrollPane = new JScrollPane(reservationTextArea);
                            reservationScrollPane.setPreferredSize(new Dimension(400, 300));

                            JTextField reservationNumberField = new JTextField(10);

                            JPanel removeReservationPanel = new JPanel();
                            removeReservationPanel.setLayout(new BoxLayout(removeReservationPanel, BoxLayout.Y_AXIS));
                            removeReservationPanel.add(reservationScrollPane);
                            removeReservationPanel.add(Box.createVerticalStrut(10));
                            removeReservationPanel.add(new JLabel("Enter reservation number:"));
                            removeReservationPanel.add(reservationNumberField);

                            int resultOption = JOptionPane.showConfirmDialog(view, removeReservationPanel, "Remove Reservation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOption == JOptionPane.OK_OPTION) {
                                String reservationIndexInput = reservationNumberField.getText().trim();
                                if (reservationIndexInput.isEmpty()) return;

                                try {
                                    int reservationIndex = Integer.parseInt(reservationIndexInput) - 1;
                                    if (reservationIndex >= 0 && reservationIndex < reservations.size()) {
                                        int confirmOption = JOptionPane.showConfirmDialog(view, "Are you sure you want to remove this reservation?", "Confirm Removal", JOptionPane.YES_NO_OPTION);
                                        if (confirmOption == JOptionPane.YES_OPTION) {
                                            hotel.removeReservation(reservationIndex);
                                            JOptionPane.showMessageDialog(view, "Reservation removed successfully.");
                                        } else {
                                            JOptionPane.showMessageDialog(view, "Reservation removal canceled.");
                                        }
                                    } else {
                                        JOptionPane.showMessageDialog(view, "Invalid reservation number. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        }
                        break;

                    case 5:
                        model.removeHotel(selectedIndex);
                        updateHotelList();
                        JOptionPane.showMessageDialog(view, "Hotel removed successfully.");
                        break;
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to manage.");
            }
        }
    }


    class BookReservationListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = view.getSelectedHotelIndex();
            if (selectedIndex >= 0) {
                Hotel hotel = model.getHotelList().get(selectedIndex);

                // Gather reservation details
                String guestName = JOptionPane.showInputDialog(view, "Enter guest name:");
                if (guestName == null || guestName.trim().isEmpty()) return; // User cancelled or input is empty

                String checkInInput = JOptionPane.showInputDialog(view, "Enter check-in date (1-30):");
                if (checkInInput == null) return; // User cancelled

                try {
                    int checkIn = Integer.parseInt(checkInInput);
                    if (checkIn < 1 || checkIn > 30) {
                        JOptionPane.showMessageDialog(view, "Invalid check-in date. Please enter a date between 1 and 30.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Exit the method
                    }

                    String checkOutInput = JOptionPane.showInputDialog(view, "Enter check-out date (2-31):");
                    if (checkOutInput == null) return; // User cancelled

                    int checkOut = Integer.parseInt(checkOutInput);
                    if (checkOut < 2 || checkOut > 31 || checkOut <= checkIn) {
                        JOptionPane.showMessageDialog(view, "Invalid check-out date. Please enter a date between 2 and 31, and ensure it's after the check-in date.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Exit the method
                    }

                    // Choose room selection option
                    String[] options = {"Pick from Available Rooms", "Pick from All Rooms", "Let System Pick"};
                    int option = JOptionPane.showOptionDialog(view, "How do you want to choose a room?", "Choose Room",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

                    Room chosenRoom = null;
                    boolean roomAvailable = false;
                    switch (option) {
                        case 0: // Pick from Available Rooms
                            StringBuilder roomListAvail = new StringBuilder("============= List of Available Rooms ============= \n");
                            ArrayList<Room> availRooms = hotel.getRooms();
                            for (int i = 0; i < availRooms.size(); i++) {
                                Room room = availRooms.get(i);
                                if (room.checkAvailability(checkIn, checkOut)) {
                                    roomListAvail.append("[").append(i + 1).append("] ").append(room.getName()).append("\n");
                                }
                            }

                            if (roomListAvail.length() == "============= List of Available Rooms ============= \n".length()) {
                                JOptionPane.showMessageDialog(view, "No rooms available for the selected dates. Please try a different date range.", "Error", JOptionPane.ERROR_MESSAGE);
                                return; // Exit the method
                            }

                            // Create JTextArea for available room list
                            JTextArea roomTextAreaAvail = new JTextArea(roomListAvail.toString());
                            roomTextAreaAvail.setEditable(false);
                            roomTextAreaAvail.setLineWrap(true);
                            roomTextAreaAvail.setWrapStyleWord(true);
                            JScrollPane roomScrollPaneAvail = new JScrollPane(roomTextAreaAvail);
                            roomScrollPaneAvail.setPreferredSize(new Dimension(400, 300));

                            // Create JTextField for room number input
                            JTextField roomNumberFieldAvail = new JTextField(10);

                            // Create JPanel to hold both JTextArea and JTextField
                            JPanel panelAvail = new JPanel();
                            panelAvail.setLayout(new BoxLayout(panelAvail, BoxLayout.Y_AXIS));
                            panelAvail.add(roomScrollPaneAvail);
                            panelAvail.add(Box.createVerticalStrut(10));
                            panelAvail.add(new JLabel("Enter room number:"));
                            panelAvail.add(roomNumberFieldAvail);

                            // Show dialog with room list and input field
                            int resultOptionAvail = JOptionPane.showConfirmDialog(view, panelAvail, "Available Room Information", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOptionAvail == JOptionPane.OK_OPTION) {
                                String roomIndexInput = roomNumberFieldAvail.getText().trim();
                                if (roomIndexInput.isEmpty()) return; // User cancelled or input is empty

                                try {
                                    int roomIndex = Integer.parseInt(roomIndexInput) - 1;
                                    if (roomIndex < 0 || roomIndex >= availRooms.size() || !availRooms.get(roomIndex).checkAvailability(checkIn, checkOut)) {
                                        JOptionPane.showMessageDialog(view, "Invalid room number. Please select an available room.", "Error", JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }
                                    chosenRoom = availRooms.get(roomIndex);
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                            }
                            break;

                        case 1: // Pick from All Rooms
                            StringBuilder roomListAll = new StringBuilder("============= List of All Rooms ============= \n");
                            ArrayList<Room> allRooms = hotel.getRooms();
                            for (int i = 0; i < allRooms.size(); i++) {
                                Room room = allRooms.get(i);
                                roomListAll.append("[").append(i + 1).append("] ").append(room.getName())
                                        .append(room.checkAvailability(checkIn, checkOut) ? " - AVAILABLE" : " - Booked").append("\n");
                            }

                            // Create JTextArea for all room list
                            JTextArea roomTextAreaAll = new JTextArea(roomListAll.toString());
                            roomTextAreaAll.setEditable(false);
                            roomTextAreaAll.setLineWrap(true);
                            roomTextAreaAll.setWrapStyleWord(true);
                            JScrollPane roomScrollPaneAll = new JScrollPane(roomTextAreaAll);
                            roomScrollPaneAll.setPreferredSize(new Dimension(400, 300));

                            // Create JTextField for room number input
                            JTextField roomNumberFieldAll = new JTextField(10);

                            // Create JPanel to hold both JTextArea and JTextField
                            JPanel panelAll = new JPanel();
                            panelAll.setLayout(new BoxLayout(panelAll, BoxLayout.Y_AXIS));
                            panelAll.add(roomScrollPaneAll);
                            panelAll.add(Box.createVerticalStrut(10));
                            panelAll.add(new JLabel("Enter room number:"));
                            panelAll.add(roomNumberFieldAll);

                            // Show dialog with room list and input field
                            int resultOptionAll = JOptionPane.showConfirmDialog(view, panelAll, "All Room Information", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);

                            if (resultOptionAll == JOptionPane.OK_OPTION) {
                                String roomIndexInput = roomNumberFieldAll.getText().trim();
                                if (roomIndexInput.isEmpty()) return; // User cancelled or input is empty

                                try {
                                    int roomIndex = Integer.parseInt(roomIndexInput) - 1;
                                    if (roomIndex < 0 || roomIndex >= allRooms.size()) {
                                        JOptionPane.showMessageDialog(view, "Invalid room number. Please select a valid room.", "Error", JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }
                                    chosenRoom = allRooms.get(roomIndex);
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                            }
                            break;

                        case 2: // Let System Pick
                            chosenRoom = hotel.pickAvailableRoom(checkIn, checkOut);
                            if (chosenRoom == null) {
                                JOptionPane.showMessageDialog(view, "No rooms available. Please try a different date range.", "Error", JOptionPane.ERROR_MESSAGE);
                                return; // Exit the method
                            }
                            break;
                    }

                    if (chosenRoom == null) {
                        JOptionPane.showMessageDialog(view, "No room selected. Please select a room.", "Error", JOptionPane.ERROR_MESSAGE);
                        return; // Exit the method
                    }

                    // Enter discount code
                    String discountCode = JOptionPane.showInputDialog(view, "Enter discount code (Enter 'NONE' if not applicable):");
                    int discountApplied = 0;
                    if (discountCode != null) {
                        switch (discountCode.toLowerCase()) {
                            case "i_work_here":
                                discountApplied = 1;
                                break;
                            case "stay4_get1":
                                discountApplied = 2;
                                break;
                            case "payday":
                                discountApplied = 3;
                                break;
                            case "none":
                                // No discount applied
                                break;
                            default:
                                // Handle invalid discount codes without displaying an error
                                // Continue processing as if no discount code was entered
                                break;
                        }
                    }

                    // Add reservation
                    boolean success = hotel.addReservation(guestName, checkIn, checkOut, chosenRoom, discountApplied);

                    if (success) {
                        // Check if a discount was applied and display success message
                        if (discountApplied > 0) {
                            JOptionPane.showMessageDialog(view, "Reservation successful with discount applied.");
                        } else {
                            JOptionPane.showMessageDialog(view, "Reservation successful.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(view, "Reservation failed. Please check the details and try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(view, "Invalid input. Please enter numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(view, "Please select a hotel to book a reservation.");
            }
        }
    }


    class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int confirm = JOptionPane.showConfirmDialog(view, "Are you sure you want to exit?");
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
    }

}
