import java.util.ArrayList;
import java.util.Scanner;

/**
 * The HRS class represents a Hotel Reservation System that manages a list of hotels.
 * It allows users to view available hotels, book rooms, and manage hotel listings.
 */
public class HRS {
    private ArrayList<Hotel> hotelList; // List of hotels
    private Scanner scanner = new Scanner(System.in); // Scanner for user input

    /**
     * Constructor to initialize HRS with an empty list of hotels.
     * Post-condition: Initializes an empty ArrayList for hotelList.
     */
    public HRS() {
        this.hotelList = new ArrayList<>();
    }

    /**
     * Displays the list of hotels available in the system.
     * Post-condition: Prints the list of available hotels to the console.
     */
    public void displayHotels() {
        if (hotelList.isEmpty()) {
            System.out.println("No hotels available.");
            return;
        }

        System.out.println("\nList of Available Hotels:");
        for (int i = 0; i < hotelList.size(); i++) {
            System.out.println("[" + (i + 1) + "] " + "\u001b[36;1m" + hotelList.get(i).getName() + "\u001b[0m");
        }
        System.out.println();
    }

    /**
     * Adds a new hotel to the system with the given name.
     *
     * @param hotelName the name of the hotel to add
     */
    public void addHotel(String hotelName) {
        Hotel newHotel = new Hotel(hotelName);
        hotelList.add(newHotel);
    }

    /**
     * Removes the hotel at the specified index from the system.
     *
     * @param index the index of the hotel to remove
     */
    public void removeHotel(int index) {
        if (index < 0 || index >= hotelList.size()) {
            System.out.println("Invalid hotel index.");
            return;
        }
        hotelList.remove(index);
        System.out.println("Hotel removed successfully.");
    }

    /**
     * Retrieves the list of hotels currently in the system.
     *
     * @return the ArrayList containing the list of hotels
     */
    public ArrayList<Hotel> getHotelList() {
        return hotelList;
    }

}
