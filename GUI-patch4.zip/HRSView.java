import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class HRSView extends JFrame {
    private JButton createHotelButton;
    private JButton viewHotelButton;
    private JButton manageHotelButton;
    private JButton bookReservationButton;
    private JButton exitButton;
    private JList<String> hotelList;
    private DefaultListModel<String> listModel;

    public HRSView() {
        setTitle("Hotel Reservation System");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize buttons with gradient background
        createHotelButton = new GradientButton("Create Hotel");
        viewHotelButton = new GradientButton("View Hotel");
        manageHotelButton = new GradientButton("Manage Hotel");
        bookReservationButton = new GradientButton("Book a Reservation");
        exitButton = new GradientButton("Exit");

        // Initialize list model and JList with custom style
        listModel = new DefaultListModel<>();
        hotelList = new JList<>(listModel);
        hotelList.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        hotelList.setFont(new Font("Futura", Font.PLAIN, 14));

        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Hotel Reservation System");
        titleLabel.setFont(new Font("Futura", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0x000080));
        titlePanel.setBackground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(new Color(0xF0F0F0));
        buttonPanel.add(createHotelButton);
        buttonPanel.add(viewHotelButton);
        buttonPanel.add(manageHotelButton);
        buttonPanel.add(bookReservationButton);
        buttonPanel.add(exitButton);

        // Create a panel for the main content
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(new JScrollPane(hotelList), BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.EAST);

        // Set overall layout and add panels
        setLayout(new BorderLayout());
        add(titlePanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }

    private class GradientButton extends JButton {
        public GradientButton(String text) {
            super(text);
            setFont(new Font("Futura", Font.BOLD, 14)); // Use Futura or an alternative font
            setForeground(new Color(0x000080)); // Set font color to white
            setFocusPainted(false);
            setOpaque(false);
            setBorderPainted(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            GradientPaint gradient = new GradientPaint(0, 0, new Color(0xB0C4DE), 0, getHeight(), new Color(0xA9A9A9));
            g2d.setPaint(gradient);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.DARK_GRAY);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
        }
    }

    public void addCreateHotelListener(ActionListener listenForCreateHotelButton) {
        createHotelButton.addActionListener(listenForCreateHotelButton);
    }

    public void addViewHotelListener(ActionListener listenForViewHotelButton) {
        viewHotelButton.addActionListener(listenForViewHotelButton);
    }

    public void addManageHotelListener(ActionListener listenForManageHotelButton) {
        manageHotelButton.addActionListener(listenForManageHotelButton);
    }

    public void addBookReservationListener(ActionListener listenForBookReservationButton) {
        bookReservationButton.addActionListener(listenForBookReservationButton);
    }

    public void addExitListener(ActionListener listenForExitButton) {
        exitButton.addActionListener(listenForExitButton);
    }

    public void updateHotelList(ArrayList<Hotel> hotels) {
        listModel.clear();
        for (Hotel hotel : hotels) {
            listModel.addElement(hotel.getName());
        }
    }

    public int getSelectedHotelIndex() {
        return hotelList.getSelectedIndex();
    }
}
