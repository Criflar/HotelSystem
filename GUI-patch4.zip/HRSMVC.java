import java.util.*;

public class HRSMVC {
    public static void main(String[] args) {
        HRS model = new HRS();
        HRSView view = new HRSView();
        HRSController controller = new HRSController(model, view);

        view.setVisible(true);
    }
}
